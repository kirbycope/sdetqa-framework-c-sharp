﻿using FrameworkCommon;
using FrameworkDesktop;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        public $safeitemname$() { }

        #region Page Elements

        #endregion Page Elements

        #region Page Methods

        #endregion Page Methods
    }
}
