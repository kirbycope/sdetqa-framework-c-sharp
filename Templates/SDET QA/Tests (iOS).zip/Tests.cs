﻿using FrameworkCommon;
using FrameworkCommon.Attributes;
using FrameworkMobile;
using NUnit.Framework;
using Assert = FrameworkCommon.Assert;

namespace $rootnamespace$
{
    [TestFixture]
    public class $safeitemname$ : TestBaseStarzAppIos
    {
        [Test]
        [Category("")]
        [Description("")]
        [Automates("")]
        [AutomatedBy("")]
        public void Tests1()
        {
            
        }
    }
}
