﻿using FrameworkCommon;
using FrameworkCommon.Attributes;
using FrameworkDesktop;
using NUnit.Framework;
using Assert = FrameworkCommon.Assert;

namespace $rootnamespace$
{
    [TestFixture]
    [Parallelizable]
    public class $safeitemname$ : TestBase
    {
        [Test]
        [Category("")]
        [Description("")]
        [Automates("")]
        [AutomatedBy("")]
        public void Tests1()
        {

        }
    }
}
